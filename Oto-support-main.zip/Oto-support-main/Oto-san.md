# Oto-support
Technical support page for the most useless bot on Discord, Oto-San!
<!DOCTYPE html><html lang="es">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
</head>
<body>  <header>
    <h1>🐱 Otosan Bot</h1>
    <p>El bot más inútil, caótico y adorable de Discord</p>
    <img src="https://i.imgur.com/8QfZKQk.png" alt="Otosan Bot" class="bot-img" />
    <br />
    <a href="https://discord.com/oauth2/authorize?client_id=TU_CLIENT_ID&permissions=0&scope=bot" class="invite-btn">Invitar a Otosan</a>
  </header>  <section>
    <h2>📜 Comandos</h2>
    <div class="commands">
      <div class="command">
        <strong>/otosan</strong>
        <p>Otosan aparece y no hace nada útil.</p>
      </div>
      <div class="command">
        <strong>/meow</strong>
        <p>Devuelve un maullido filosófico.</p>
      </div>
      <div class="command">
        <strong>/status</strong>
        <p>Muestra el estado emocional de Otosan.</p>
      </div>
      <div class="command">
        <strong>/fact</strong>
        <p>Dato inútil que nadie pidió.</p>
      </div>
    </div>
  </section>  <section>
    <h2>⚠️ Términos y Condiciones</h2>
    <p>
      Al invitar a Otosan Bot a tu servidor aceptas que:
    </p>
    <ul style="text-align:left; max-width:700px; margin:0 auto;">
      <li>El bot puede cambiar, romperse o desaparecer sin previo aviso.</li>
      <li>No se garantiza utilidad alguna.</li>
      <li>No se almacena información personal fuera de Discord.</li>
      <li>El uso indebido del bot puede resultar en bloqueo.</li>
      <li>Este bot es solo para entretenimiento.</li>
    </ul>
  </section>  <footer>
    <p>© 2026 Otosan Bot — No afiliado oficialmente con Discord ni Azumanga Daioh</p>
  </footer></body>
</html>
